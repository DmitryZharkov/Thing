/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simplenums;

import java.io.PrintWriter;

/**
 *
 * @author zharkov
 */
public class SimpleNums {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Thing thing;
        PrintWriter pw= new PrintWriter(System.out,true);
        final int size=Integer.MAX_VALUE/6;
        long startTime =System.currentTimeMillis();
        int inum=Integer.MAX_VALUE;
        int[] nums=new int[size];
        
        for (int n=0;n<nums.length;n++)
        {
            nums[n]=inum--;
        }

        thing=new Thing(1,2,3,4,5,6,7,8,9,10);
        pw.println("Минимальное значение: " + thing.min());
        pw.println("Максимальное значение: " + thing.max());
        pw.println("Среднее значение: " + thing.avg());
        pw.println("Время выполнения: " + (float)(System.currentTimeMillis()-startTime)/1000 + " сек.");
        
        thing=new Thing(nums);
        pw.println("Минимальное значение: " + thing.min());
        pw.println("Максимальное значение: " + thing.max());
        pw.println("Среднее значение: " + thing.avg());
        pw.println("Время выполнения: " + (float)(System.currentTimeMillis()-startTime)/1000 + " сек.");
        
        thing=new Thing(0,0,0);
        pw.println("Минимальное значение: " + thing.min());
        pw.println("Максимальное значение: " + thing.max());
        pw.println("Среднее значение: " + thing.avg());
        pw.println("Время выполнения: " + (float)(System.currentTimeMillis()-startTime)/1000 + " сек.");
        
        Thing thingT=new Thing(nums);
        for (int n=0;n<10;n++)
        {
       new Thread(() -> {
        System.out.println("Среднее значение: " + thingT.avg());
        System.out.println("Максимальное значение: " + thingT.max());
        System.out.println("Минимальное значение: " + thingT.min());
       }).start();
       try{
       Thread.sleep(10);
       }
       catch(Exception e){}       
        }
 
    }
    
}
