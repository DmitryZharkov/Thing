/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simplenumswithexceptions;

import java.io.PrintWriter;

/**
 *
 * @author zharkov
 */
public class SimpleNumsWithExceptions {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Thing thing;
        PrintWriter pw= new PrintWriter(System.out,true);
        final int size=Integer.MAX_VALUE/6;
        long time =System.currentTimeMillis();
        int inum=0;
        int[] nums=new int[size];
        
        for (int n=0;n<nums.length;n++)
        {
            nums[n]=inum++;
        }
        
         try{
             
        thing=new Thing(1,2,3,4,5,6,7,8,9,10);        
        pw.println("Минимальное значение: " + thing.min());
        pw.println("Максимальное значение: " + thing.max());
        pw.println("Среднее значение: " + thing.avg());
        pw.println("Время выполнения: " + (float)(System.currentTimeMillis()-time)/1000 + " сек.");
        
        thing=new Thing(nums);
        pw.println("Минимальное значение: " + thing.min());
        pw.println("Максимальное значение: " + thing.max());
        pw.println("Среднее значение: " + thing.avg());
        pw.println("Время выполнения: " + (float)(System.currentTimeMillis()-time)/1000 + " сек.");

        thing=new Thing(0,0);       
        pw.println("Минимальное значение: " + thing.min());
        pw.println("Максимальное значение: " + thing.max());
        pw.println("Среднее значение: " + thing.avg());
        pw.println("Время выполнения: " + (float)(System.currentTimeMillis()-time)/1000 + " сек.");
    }
        catch (EmptyArrayException e)
        {
            pw.println(e.toString());
        }
    }
}
