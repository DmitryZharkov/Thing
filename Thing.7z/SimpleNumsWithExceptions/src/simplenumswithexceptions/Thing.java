/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simplenumswithexceptions;

/**
 *
 * @author zharkov
 */
public class Thing {
    int[] nums;
    
    public Thing (int ... nums) throws EmptyArrayException
    {
        if (nums.length==0)      
        {
            
        throw new EmptyArrayException();   //Если неопытный не такой уж неопытный

        }       
        else
        
        {
            this.nums=nums;
        }
            
    }
    
    public int min(){
     
        int min=nums[0];
        
        for (int n=1;n<nums.length;n++)
        {
            if (nums[n]<min)
                min=nums[n];
        }
     return min;
        
    }
    
    public int max(){

     int max=nums[0];
        
        for (int n=1;n<nums.length;n++)
        {
            if (nums[n]>max)
                max=nums[n];
        }
     return max;
    }
    
    public double avg(){
        long sum=0;
        
         for (int n=0;n<nums.length;n++)
         {
        sum+=nums[n];
     }

     if (sum==0)
     {
        return 0;
     }
     return (double)sum/nums.length;
    }
    
}
