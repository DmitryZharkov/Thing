/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author zharkov
 */

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import simplenumswithexceptions.Thing;
import org.junit.Before;
import org.junit.Test;
import simplenumswithexceptions.EmptyArrayException;


public class TestSNWE {
    
    Thing thing;
      
    @Before public void initialize()
    {
       try{
                thing = new Thing(1,2,3,4);
                }
            catch (EmptyArrayException e)
            {
                System.out.println(e);
            } 
    }
            
    @Test
    public void testThingMin()
    {
        
                assertEquals(1,thing.min());

    }
    
    @Test
    public void testThingMax()
    {

                assertEquals(4,thing.max());

    }
    
    @Test
    public void testThingAvg()
    {

                assertEquals(2.5,thing.avg(),0);

    }
    @Test
    public void testThingNull()
    {
            try{
                Thing thing = new Thing();
                fail("EmptyArrayException exception was not occured.");
                }
            catch (EmptyArrayException e)
            {
            }
    }
}

