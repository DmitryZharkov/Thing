/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication13;

import java.util.Arrays;

/**
 *
 * @author zharkov
 */
public class Thing {
    
    int[] nums;
    
    public Thing(int ... nums)
    {
        if (nums.length==0)
            
        {           
        System.out.println("Массив не может быть пустым!");     //Exception не бросаем из-за неопытного
        System.exit(-1);
        }      
        else
        
        {
            this.nums=nums;
        }          
    }
    
    public int min(){
        
     return Arrays.stream(nums).parallel().min().getAsInt();        
    }
    
    public int max(){

     return Arrays.stream(nums).parallel().max().getAsInt();   
    }
    
    public double avg(){
        
     return Arrays.stream(nums).parallel().average().getAsDouble();   
    }
}
